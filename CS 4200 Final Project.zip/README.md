# CS-4200-AI-Final-Project
Very basic convolutional neural network made with assistance from Deepseek, Google Gemini, and Data Science Agent
The following project was created and is intended to run on PyCharm (2025 Community Edition), please install all the necessary libraries and packages if the project isn't running properly.
Includes:
	-Reading in dataset from Kagglehub
	-Processing dataset to reduce overfitting
	-TensorFlow Keras Convolutional Neural Network Model
	-Prediction Model derived from original model
	-PyGame drawing program allowing user to draw and feed test input to model